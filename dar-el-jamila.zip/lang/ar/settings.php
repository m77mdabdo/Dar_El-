<?php

return [
    'title' => 'الإعدادات',
    'store_name' => 'اسم المتجر',
    'support_email' => 'بريد الدعم الفني',
    'whatsapp_number' => 'رقم الواتساب',
    'default_shipping_fee' => 'رسوم الشحن الافتراضية (جنيه مصري)',
    'facebook_url' => 'رابط فيسبوك',
    'instagram_url' => 'رابط إنستغرام',
    'tiktok_url' => 'رابط تيك توك',
    'security' => 'الأمان',
    'login_alerts_enabled' => 'إرسال بريد تنبيه عند تسجيل دخول العميل',
    'login_alerts_enabled_hint' => 'يُخطر صاحب الحساب عبر البريد الإلكتروني في كل مرة يتم فيها تسجيل الدخول إلى حسابه، مع الوقت وعنوان IP والجهاز المستخدم.',

    'cart_reminders' => 'تذكيرات السلة المتروكة',
    'cart_reminders_enabled' => 'تفعيل التذكيرات التلقائية',
    'cart_reminder_notification_enabled' => 'إرسال إشعار داخل الموقع للعميل إلى جانب البريد الإلكتروني',
    'cart_reminder_first_delay_hours' => 'تأخير التذكير الأول (بالساعات)',
    'cart_reminder_interval_hours' => 'الفاصل الزمني بين التذكيرات (بالساعات)',
    'cart_max_reminders' => 'الحد الأقصى لعدد التذكيرات',
    'cart_reminders_hint' => 'تصبح السلة مؤهلة لأول تذكير بعد أن تظل بلا نشاط للمدة المحددة أعلاه، ثم كل فترة زمنية بعد ذلك، حتى الحد الأقصى — يتم التحقق كل 30 دقيقة بواسطة المجدول. زر "إرسال تذكير" الخاص بالمشرف يعمل دائمًا بغض النظر عن هذه الإعدادات.',

    'site_images' => 'صور الموقع',
    'images_hint' => 'JPG أو PNG أو WEBP بحد أقصى 4 ميجابايت لكل صورة. رفع صورة جديدة يستبدل الصورة الحالية.',
    'save_settings' => 'حفظ الإعدادات',
    'updated' => 'تم تحديث الإعدادات.',

    'image_home_hero_image' => 'خلفية الصفحة الرئيسية',
    'image_shop_hero_image' => 'صورة رأس صفحة المتجر',
    'image_about_hero_image' => 'صورة رأس صفحة من نحن',
    'image_about_story_image' => 'صورة قصة صفحة من نحن',
    'image_services_hero_image' => 'صورة رأس صفحة الخدمات',
    'image_blog_hero_image' => 'صورة رأس صفحة المدونة',
    'image_contact_hero_image' => 'صورة رأس صفحة التواصل',
    'image_checkout_hero_image' => 'صورة رأس صفحة إتمام الطلب',
];
